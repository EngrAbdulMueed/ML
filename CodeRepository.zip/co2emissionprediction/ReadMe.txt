To start our small application, start the "Final_Prototype.ipynb" file. 
Then you can just run every cell in the notebook.